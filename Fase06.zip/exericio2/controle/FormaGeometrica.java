package controle;

public interface FormaGeometrica {
	double calcularArea();
	double calcularPerimetro();
}
