package controle;

public interface DispositivoEletronico {
	void ligar();
    void desligar();
}
